var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["bce5f060-eec1-4bf1-ba3e-dc983c29845e","0e12771c-b2d2-42e6-a80c-734feeec4fb8","2080afd0-6913-43ac-a52a-e3c2eebe6dca","8d67616e-785c-4300-ba46-87fcf788ed54","f56d9b1b-d098-4f63-acff-4850d5cafff3","b0361c13-14d4-4953-801d-c37c9d4010f2","92896c57-93ac-43a4-a7ec-e09cf9b34026","c2f33c6b-eb92-4814-bc31-689e5253f2e2","6b9ea02b-85a5-40a6-a63e-be3dc89fab7d","68a8364d-62a6-4b45-90d2-3ebb25a4a58e","adae222c-a903-4dc5-be98-ce973332fa0a","58bcffe6-dd18-4859-aa32-2e0f3d4cf128","f2ab873d-fc97-4e9b-96f4-ff8ca4ed0d2a","a8a6ce35-e844-4f0a-b9ce-4967b35328bd","69667595-a7fe-473c-b402-d493a90bb781","02ac9140-426d-46eb-bfd5-9c71f9d9ca33"],"propsByKey":{"bce5f060-eec1-4bf1-ba3e-dc983c29845e":{"name":"ladrão","sourceUrl":null,"frameSize":{"x":13,"y":30},"frameCount":1,"looping":true,"frameDelay":12,"version":"XMswN_3gj29AIu87TQKyk8GkQsxHb0nv","loadedFromSource":true,"saved":true,"sourceSize":{"x":13,"y":30},"rootRelativePath":"assets/bce5f060-eec1-4bf1-ba3e-dc983c29845e.png"},"0e12771c-b2d2-42e6-a80c-734feeec4fb8":{"name":"baixo","sourceUrl":null,"frameSize":{"x":14,"y":30},"frameCount":2,"looping":true,"frameDelay":12,"version":"i2MX_jnSVnk1VazkeECCyW4ws7ImNkqO","loadedFromSource":true,"saved":true,"sourceSize":{"x":28,"y":30},"rootRelativePath":"assets/0e12771c-b2d2-42e6-a80c-734feeec4fb8.png"},"2080afd0-6913-43ac-a52a-e3c2eebe6dca":{"name":"frente","sourceUrl":null,"frameSize":{"x":17,"y":30},"frameCount":4,"looping":true,"frameDelay":12,"version":"5CNay3r0YwGefQibahJejMoKKdea4JNU","loadedFromSource":true,"saved":true,"sourceSize":{"x":51,"y":60},"rootRelativePath":"assets/2080afd0-6913-43ac-a52a-e3c2eebe6dca.png"},"8d67616e-785c-4300-ba46-87fcf788ed54":{"name":"tras","sourceUrl":null,"frameSize":{"x":17,"y":30},"frameCount":4,"looping":true,"frameDelay":12,"version":"5IhJsRx0bdQx6aI8t1VokWyn9SkEOC54","loadedFromSource":true,"saved":true,"sourceSize":{"x":51,"y":60},"rootRelativePath":"assets/8d67616e-785c-4300-ba46-87fcf788ed54.png"},"f56d9b1b-d098-4f63-acff-4850d5cafff3":{"name":"cima","sourceUrl":null,"frameSize":{"x":14,"y":28},"frameCount":2,"looping":true,"frameDelay":12,"version":"dcOT376d2ZRJxuh_ThM6Y34vi1PepQx2","loadedFromSource":true,"saved":true,"sourceSize":{"x":28,"y":28},"rootRelativePath":"assets/f56d9b1b-d098-4f63-acff-4850d5cafff3.png"},"b0361c13-14d4-4953-801d-c37c9d4010f2":{"name":"guarda","sourceUrl":null,"frameSize":{"x":13,"y":26},"frameCount":4,"looping":true,"frameDelay":12,"version":"PxscSYO.e71kiEauxIk.PWa5pzGlAzHm","loadedFromSource":true,"saved":true,"sourceSize":{"x":39,"y":52},"rootRelativePath":"assets/b0361c13-14d4-4953-801d-c37c9d4010f2.png"},"92896c57-93ac-43a4-a7ec-e09cf9b34026":{"name":"guarda1","sourceUrl":null,"frameSize":{"x":13,"y":26},"frameCount":4,"looping":true,"frameDelay":12,"version":"O3.YsdXvm5w6wjtd07FSRbW_FtG_y2EX","loadedFromSource":true,"saved":true,"sourceSize":{"x":39,"y":52},"rootRelativePath":"assets/92896c57-93ac-43a4-a7ec-e09cf9b34026.png"},"c2f33c6b-eb92-4814-bc31-689e5253f2e2":{"name":"diamante","sourceUrl":"assets/v3/animations/-U60hof3FS6FgxVVvRmt6TXFkCOV3P0ReQA3jIlnyhs/c2f33c6b-eb92-4814-bc31-689e5253f2e2.png","frameSize":{"x":253,"y":199},"frameCount":1,"looping":true,"frameDelay":4,"version":"AjEoA43Vz_s3tb2jm5zJk.qpIFyaigw3","loadedFromSource":true,"saved":true,"sourceSize":{"x":253,"y":199},"rootRelativePath":"assets/v3/animations/-U60hof3FS6FgxVVvRmt6TXFkCOV3P0ReQA3jIlnyhs/c2f33c6b-eb92-4814-bc31-689e5253f2e2.png"},"6b9ea02b-85a5-40a6-a63e-be3dc89fab7d":{"name":"alarme","sourceUrl":null,"frameSize":{"x":100,"y":4},"frameCount":1,"looping":true,"frameDelay":12,"version":"BeDedzi_5.qcrBBE8h08xYq7F_Yi7N_D","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":4},"rootRelativePath":"assets/6b9ea02b-85a5-40a6-a63e-be3dc89fab7d.png"},"68a8364d-62a6-4b45-90d2-3ebb25a4a58e":{"name":"gameover","sourceUrl":null,"frameSize":{"x":16,"y":25},"frameCount":1,"looping":true,"frameDelay":12,"version":"jDdo35MwvshV27qJzYJbv5TnhC7JFOm8","loadedFromSource":true,"saved":true,"sourceSize":{"x":16,"y":25},"rootRelativePath":"assets/68a8364d-62a6-4b45-90d2-3ebb25a4a58e.png"},"adae222c-a903-4dc5-be98-ce973332fa0a":{"name":"perdemo","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"HTuoSAob4uOXXhemIeWaDDVg.8uMAjpZ","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/adae222c-a903-4dc5-be98-ce973332fa0a.png"},"58bcffe6-dd18-4859-aa32-2e0f3d4cf128":{"name":"vazio","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"KK9gH4cz8Z7vdB9wZWKh1Xvei2DY4N8k","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/58bcffe6-dd18-4859-aa32-2e0f3d4cf128.png"},"f2ab873d-fc97-4e9b-96f4-ff8ca4ed0d2a":{"name":"bom","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"jYsfUXiPAghLquQdBU1p5e52zLnX5CMs","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/f2ab873d-fc97-4e9b-96f4-ff8ca4ed0d2a.png"},"a8a6ce35-e844-4f0a-b9ce-4967b35328bd":{"name":"museu","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"6IJqRuXO0SrQUOn5OHnk36h85JnVjDrE","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/a8a6ce35-e844-4f0a-b9ce-4967b35328bd.png"},"69667595-a7fe-473c-b402-d493a90bb781":{"name":"porta","sourceUrl":null,"frameSize":{"x":100,"y":100},"frameCount":1,"looping":true,"frameDelay":12,"version":"ugX8TZRqlo0VCyVfftcwQTEVxTbs8.Qw","loadedFromSource":true,"saved":true,"sourceSize":{"x":100,"y":100},"rootRelativePath":"assets/69667595-a7fe-473c-b402-d493a90bb781.png"},"02ac9140-426d-46eb-bfd5-9c71f9d9ca33":{"name":"fim","sourceUrl":null,"frameSize":{"x":69,"y":85},"frameCount":1,"looping":true,"frameDelay":12,"version":"15btguEW.P_9MlNzL22J3mehW6tuHX6w","loadedFromSource":true,"saved":true,"sourceSize":{"x":69,"y":85},"rootRelativePath":"assets/02ac9140-426d-46eb-bfd5-9c71f9d9ca33.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var museu= createSprite(200,200,200,200)
museu.setAnimation("museu")
museu.scale=4

var ladrão = createSprite(30, 350, 2, 2);
ladrão.setAnimation("ladrão")
ladrão.scale=1.8

var guarda = createSprite(30, 80, 20, 20);
guarda.velocityX=-1

var diamante= createSprite(368, 30, 20, 20);
diamante.setAnimation('diamante')
diamante.scale=0.1

var chegada =createSprite(20, 360, 5, 80)


var alarme = createSprite(54, 237, 20, 20)
alarme.setAnimation("alarme")
alarme.scale=2
alarme.velocityX=+10

createEdgeSprites()
function draw() {
 
 
 
 if (keyDown("right")){
 ladrão.x=ladrão.x+10
   ladrão.setAnimation("frente")
 }
 
 if (keyDown("left")){
   ladrão.x=ladrão.x-10
   ladrão.setAnimation("tras")
 }
 
 if (keyDown("up")){
 ladrão.y=ladrão.y-10
 ladrão.setAnimation("cima")
 }
 
if (keyDown("down")){
  ladrão.y=ladrão.y+10
  ladrão.setAnimation("baixo")
}
 
if (guarda.bounceOff(leftEdge)){
  guarda.setAnimation("guarda1")
guarda.scale=2
  
}
 if (guarda.bounceOff(rightEdge)){
   guarda.setAnimation("guarda")
   guarda.scale=2
 }
 
  if (ladrão.isTouching(guarda)|| guarda.isTouching(ladrão)|| alarme.isTouching(ladrão)|| ladrão.isTouching(alarme)){
 var perdemo=createSprite(200, 200, 200,200)
 var gameOver= createSprite(200, 300, 20)
 var ruim= createSprite(200,200)
  gameOver.setAnimation('perdemo')
  gameOver.scale=2.5
    ladrão.velocityY=0
    ladrão.velocityX=0
    ladrão.scale=2
    gameOver.setAnimation('gameover')
    perdemo.setAnimation('vazio')
    ruim.setAnimation('perdemo')
    ruim.scale=2
    perdemo.scale=200
     playSound("assets/category_male_voiceover/mission_failed_male.mp3",false)
   guarda.velocityX=0
   alarme.velocityX=0
    alarme.velocityY=+200457871782488427
    guarda.velocityY=+200725979777959755
  }
   
 if (diamante.isTouching(chegada)){
 var fim= createSprite(200, 200, 200, 200)
 var boa = createSprite(200, 200, 20, 20)
var ganhemo= createSprite(200,300,20, 20)
 fim.setAnimation('vazio')
 fim.scale=20
 boa.scale=3
 ganhemo.setAnimation("bom")
 ganhemo.scale=2
 boa.setAnimation("fim")
playSound("assets/category_male_voiceover/mission_completed_male.mp3")
chegada.velocityY=+24282842
   
 }
 text.shapeColor='yellow'
 diamante.collide(chegada)
 ladrão.displace(diamante)
 alarme.bounceOff(leftEdge)
 alarme.bounceOff(rightEdge)
 
 ladrão.collide(bottomEdge)
 ladrão.collide(rightEdge)
 ladrão.collide(leftEdge)
 if (ladrão.isTouching(diamante)){
 guarda.x=ladrão.x=1
 guarda.y=ladrão.y=0}
 
 
 
 
 drawSprites();

  
  
}
// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
